//
//  LoginViewController.swift
//  CallAppSDk
//
//  Created by Jitender SIngh on 11/26/23.
//

import UIKit
import CometChatUIKitSwift

class LoginViewController: UIViewController {
    
    @IBOutlet weak var msgLb: UILabel!
    
    
    
    
    
    
    @IBOutlet weak var usernameIP: UITextField!
    

    @IBOutlet weak var passwordIP: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func onLogin(_ sender: Any) {
        
        
        guard !(self.usernameIP.text!).isEmpty else {
                self.msgLb.text = "Please enter username!"
                return
            }
        guard !(self.passwordIP.text!).isEmpty else {
                self.msgLb.text = "Please enter password!"
                return
            }
            Task{
                do{
                    let user = try await AuthenticationManager.shared.signIn(email: self.usernameIP.text!, password: self.passwordIP.text!)
                    let uid = user.uid
                    CometChatUIKit.login(uid: uid) { result in
                        switch result {
                        case .success(let user):
                            debugPrint("User logged in successfully  \(String(describing: user.name))")
                            break
                        case .onError(let error):
                            debugPrint("Login failed with exception: \(error.errorDescription)")
                            break
                        @unknown default:
                            break
                        }
                    }
                    self.performSegue(withIdentifier: "chatsegue", sender: self)
                }
                catch {
                    print(error)
                    self.msgLb.text = "Invalid Login Credentials"
                    
                }
            }
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


