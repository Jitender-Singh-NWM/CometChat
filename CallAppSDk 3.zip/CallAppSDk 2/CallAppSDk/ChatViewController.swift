//
//  ChatViewController.swift
//  CallAppSDk
//
//  Created by Jitender SIngh on 11/25/23.
//

import UIKit
import CometChatUIKitSwift


class ChatViewController: UIViewController {

    override func viewDidLoad() {
        print("IN View Did Load 2")
        super.viewDidLoad()
        let cometChatConversationsWithMessages = CometChatConversationsWithMessages()
        cometChatConversationsWithMessages.navigationItem.setHidesBackButton(true, animated: false)
        self.navigationController?.pushViewController(cometChatConversationsWithMessages, animated: true)
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
