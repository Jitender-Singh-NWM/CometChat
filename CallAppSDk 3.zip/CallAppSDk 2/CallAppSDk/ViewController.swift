//
//  ViewController.swift
//  CallAppSDk
//
//  Created by Jitender SIngh on 11/25/23.
//

import UIKit
import CometChatUIKitSwift

class ViewController: UIViewController {
    
    
    @IBOutlet weak var imgOutlet: UIImageView!
    
    override func viewDidLoad() {
        
        
        
        
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "bg.jpg")!)
        
        self.Updateandanimate("logo")
        
        /*print("IN View Did Load")
        let uid = "superhero2"
        let name =  "Captain America"
        //let avatar = <# Enter User's Avatar URL Here #>
                
        let user = User(uid: uid, name: name)
        //user.avatar =  avatar
        //let user = User(uid: self.user.uid, name: self.nameTF.text!)
                    CometChatUIKit.logout(user: user){ result in
                        switch result {
                        case .success(_):
                            debugPrint("User logout successful \(String(describing: user.name))")
                            break
                        case .onError(let error):
                            debugPrint("Logout of user failed with exception: \(error.errorDescription)")
                            break
                        @unknown default:
                            break
                        }
                    }
        
        
               
            CometChatUIKit.login(uid: uid) { result in
                    switch result {
                    case .success(let user):
                        debugPrint("User logged in successfully  \(user.name)")
                        
                        DispatchQueue.main.async { () -> Void in
                            self.performSegue(withIdentifier: "chatsegue", sender: Any?.self)
                             }
                        
                      break
                    case .onError(let error):
                        debugPrint("Login failed with exception: \(error.errorDescription)")
                      break
                    }
             }*/
            
            
        }
    
    func Updateandanimate(_ imagename:String){
        //make the current image as opaque.(alpha should be zero)
        
        UIView.animate(withDuration: 1, animations: {
            self.imgOutlet.alpha=0;
        })
        //And assign the new image with animations and make it transparent alpha shoule be 1
        UIView.animate(withDuration:1,delay: 0.5, animations:{
            self.imgOutlet.alpha=1;
            self.imgOutlet.image=UIImage(named: imagename)
        } )
        
    }
        
        
    }

